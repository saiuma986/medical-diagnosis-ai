import { GoogleGenAI, Type } from "@google/genai";
import type { PatientHistory, MedicalImages, DiagnosisResult } from '../types';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const diagnosisSchema = {
  type: Type.OBJECT,
  properties: {
    predictedDiseases: {
      type: Type.ARRAY,
      description: 'List of the top 3 most likely diseases, sorted by confidence.',
      items: {
        type: Type.OBJECT,
        properties: {
          disease: {
            type: Type.STRING,
            description: 'The name of the potential disease or condition.',
          },
          confidence: {
            type: Type.NUMBER,
            description: 'The AI\'s confidence level (0-100) for this diagnosis.',
          },
          explanation: {
            type: Type.STRING,
            description: 'A brief explanation of why this disease is considered, based on the provided data.',
          },
        },
        required: ['disease', 'confidence', 'explanation'],
      },
    },
    summary: {
      type: Type.STRING,
      description: 'A comprehensive summary combining findings from both patient history and the medical image. Include potential next steps or recommendations for further tests.',
    },
    overallRisk: {
        type: Type.STRING,
        description: "An overall risk assessment for the patient based on all available data. Must be one of: 'Low', 'Medium', or 'High'.",
        enum: ['Low', 'Medium', 'High']
    }
  },
  required: ['predictedDiseases', 'summary', 'overallRisk'],
};


export const getDiagnosis = async (
  patientHistory: PatientHistory,
  medicalImages: MedicalImages
): Promise<DiagnosisResult> => {
  const model = 'gemini-2.5-flash';

  const patientHistoryText = `
    Patient Information:
    - Name: ${patientHistory.name}
    - Age: ${patientHistory.age}
    - Gender: ${patientHistory.gender}
    - Current Symptoms: ${patientHistory.symptoms}
    - Past Medical History: ${patientHistory.medicalHistory}
    - Blood Pressure: ${patientHistory.bloodPressure || 'Not provided'}
    - Blood Sugar: ${patientHistory.bloodSugar || 'Not provided'}
  `;
  
  const imageParts: any[] = [];
  const uploadedImageTypes: string[] = [];

  for (const [type, imageFile] of Object.entries(medicalImages)) {
      if (imageFile) {
          const [header, base64Data] = imageFile.base64.split(',');
          const mimeType = header.match(/:(.*?);/)?.[1] || 'image/jpeg';

          imageParts.push({
              inlineData: {
                  mimeType: mimeType,
                  data: base64Data,
              },
          });
          uploadedImageTypes.push(type.toUpperCase());
      }
  }

  const imageAnalysisInstruction = imageParts.length > 0 
    ? `Analyze the attached medical image(s) (${uploadedImageTypes.join(', ')}) for any abnormalities.`
    : `No medical images were provided. Base your analysis solely on the patient's history.`;
  
  const summaryInstruction = imageParts.length > 0 
    ? `Generate a comprehensive summary and suggest potential next steps for a healthcare professional. Your summary must incorporate any relevant findings from the image(s).`
    : `Generate a comprehensive summary and suggest potential next steps for a healthcare professional based on the patient history alone.`;

  const textPart = {
    text: `
      Analyze the following patient data ${imageParts.length > 0 ? 'and medical image(s)' : ''} to provide a differential diagnosis.
      You are an AI medical diagnosis support system. Your goal is to assist healthcare professionals, not replace them.
      Your analysis must be based SOLELY on the information provided. Do not invent details.
      
      Instructions:
      1.  Carefully review the structured patient history.
      2.  ${imageAnalysisInstruction}
      3.  Synthesize the findings from all available sources.
      4.  Identify the top 3 most likely conditions.
      5.  Provide a confidence score and a brief rationale for each condition.
      6.  Determine an overall risk level ('Low', 'Medium', or 'High').
      7.  ${summaryInstruction}
      
      ${patientHistoryText}
    `,
  };

  const contents = { parts: [textPart, ...imageParts] };

  try {
    const response = await ai.models.generateContent({
      model: model,
      contents: contents,
      config: {
        responseMimeType: "application/json",
        responseSchema: diagnosisSchema,
        temperature: 0.2,
      },
    });

    const jsonText = response.text.trim();
    const cleanJsonText = jsonText.replace(/^```json\s*/, '').replace(/```$/, '');
    const parsedResult = JSON.parse(cleanJsonText) as DiagnosisResult;

    parsedResult.predictedDiseases.sort((a, b) => b.confidence - a.confidence);
    
    return parsedResult;

  } catch (error) {
    console.error("Error calling Gemini API:", error);
    throw new Error("Failed to communicate with the AI model.");
  }
};