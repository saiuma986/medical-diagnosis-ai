import React, { useState, useCallback, useEffect } from 'react';
// FIX: Added 'Patient' to the import list from the corrected types file and useEffect for the usePatients hook.
import type { Patient, PatientHistory, DiagnosisResult, MedicalImages } from './types';
import { DiagnosisResultDisplay } from './components/DiagnosisResultDisplay';
import { StethoscopeIcon } from './components/icons/StethoscopeIcon';
import { getDiagnosis } from './services/geminiService';
import { translations } from './translations';
import { LandingPage, PatientDetailsPage, MedicalInfoPage, ImageUploadPage, ReviewPage } from './components/pages';

type Page = 'landing' | 'details' | 'medical' | 'image' | 'review' | 'result';

// FIX: Added usePatients hook to manage patient data persistence in localStorage.
const usePatients = (): [Patient[], React.Dispatch<React.SetStateAction<Patient[]>>] => {
  const [patients, setPatients] = useState<Patient[]>(() => {
    try {
      const savedPatients = window.localStorage.getItem('medicube-patients');
      return savedPatients ? JSON.parse(savedPatients) : [];
    } catch (error) {
      console.error('Failed to load patients from localStorage:', error);
      return [];
    }
  });

  useEffect(() => {
    try {
      window.localStorage.setItem('medicube-patients', JSON.stringify(patients));
    } catch (error) {
      console.error('Failed to save patients to localStorage:', error);
    }
  }, [patients]);

  return [patients, setPatients];
};

const App: React.FC = () => {
  const [language, setLanguage] = useState<'en' | 'te' | 'hi'>('en');
  const [currentPage, setCurrentPage] = useState<Page>('landing');
  
  // FIX: Added state for managing the list of patients.
  const [patients, setPatients] = usePatients();

  const initialPatientHistory: PatientHistory = {
    name: '',
    age: '',
    gender: 'male',
    symptoms: '',
    medicalHistory: '',
    bloodPressure: '',
    bloodSugar: '',
  };
  
  const initialMedicalImages: MedicalImages = {
    xray: null,
    mri: null,
    ct: null,
    other: null,
  };

  const [patientHistory, setPatientHistory] = useState<PatientHistory>(initialPatientHistory);
  const [medicalImages, setMedicalImages] = useState<MedicalImages>(initialMedicalImages);
  const [diagnosisResult, setDiagnosisResult] = useState<DiagnosisResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const t = translations[language];

  const handleFormChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPatientHistory(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleImageChange = useCallback((file: File | null, type: keyof MedicalImages) => {
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setMedicalImages(prev => ({ ...prev, [type]: { file: file, base64: reader.result as string } }));
      };
      reader.readAsDataURL(file);
    } else {
      setMedicalImages(prev => ({ ...prev, [type]: null }));
    }
  }, []);

  const handleAnalyze = async () => {
    if (!patientHistory.name || !patientHistory.age || !patientHistory.symptoms) {
      setError(t.fillAllFields);
      return;
    }
    setError(null);
    setIsLoading(true);
    setDiagnosisResult(null);
    setCurrentPage('result');

    try {
      const result = await getDiagnosis(patientHistory, medicalImages);
      setDiagnosisResult(result);
      
      // FIX: Added logic to save the new patient record after a successful diagnosis.
      const newPatient: Patient = {
        id: `patient_${Date.now()}`,
        timestamp: Date.now(),
        history: patientHistory,
        images: medicalImages,
        result: result,
      };
      setPatients(prev => [newPatient, ...prev]);

    } catch (err) {
      console.error('Error getting diagnosis:', err);
      setError(t.failedToGetDiagnosis);
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewDiagnosis = () => {
    setPatientHistory(initialPatientHistory);
    setMedicalImages(initialMedicalImages);
    setDiagnosisResult(null);
    setError(null);
    setIsLoading(false);
    setCurrentPage('landing');
  };

  // FIX: Added handlers for starting a new diagnosis, selecting, and deleting a patient to support patient history functionality.
  const handleStartNewDiagnosis = () => {
    setPatientHistory(initialPatientHistory);
    setMedicalImages(initialMedicalImages);
    setDiagnosisResult(null);
    setError(null);
    setIsLoading(false);
    setCurrentPage('details');
  };

  const handleSelectPatient = (patient: Patient) => {
    setPatientHistory(patient.history);
    setMedicalImages(patient.images);
    setDiagnosisResult(patient.result);
    setError(null);
    setCurrentPage('result');
  };

  const handleDeletePatient = (patientId: string) => {
    setPatients(prev => prev.filter(p => p.id !== patientId));
  };

  const handleNextPage = () => {
      setError(null);
      switch(currentPage) {
          case 'details':
              if (!patientHistory.name || !patientHistory.age) {
                  setError(t.fillAllFields);
                  return;
              }
              setCurrentPage('medical');
              break;
          case 'medical':
              if (!patientHistory.symptoms || !patientHistory.medicalHistory) {
                  setError(t.fillAllFields);
                  return;
              }
              setCurrentPage('image');
              break;
          case 'image':
              setCurrentPage('review');
              break;
      }
  };

  const handlePrevPage = () => {
      switch(currentPage) {
          case 'medical':
              setCurrentPage('details');
              break;
          case 'image':
              setCurrentPage('medical');
              break;
          case 'review':
              setCurrentPage('image');
              break;
      }
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'landing':
        // FIX: Passed required props (patients, onSelectPatient, onDeletePatient) to LandingPage and updated onStart handler.
        return <LandingPage t={t} onStart={handleStartNewDiagnosis} patients={patients} onSelectPatient={handleSelectPatient} onDeletePatient={handleDeletePatient} />;
      case 'details':
        return <PatientDetailsPage t={t} patientHistory={patientHistory} onFormChange={handleFormChange} onNext={handleNextPage} error={error} />;
      case 'medical':
        return <MedicalInfoPage t={t} patientHistory={patientHistory} onFormChange={handleFormChange} onNext={handleNextPage} onBack={handlePrevPage} error={error} />;
      case 'image':
        return <ImageUploadPage t={t} medicalImages={medicalImages} onImageChange={handleImageChange} onNext={handleNextPage} onBack={handlePrevPage} error={error} />;
      case 'review':
        return <ReviewPage t={t} patientHistory={patientHistory} medicalImages={medicalImages} onBack={handlePrevPage} onAnalyze={handleAnalyze} isLoading={isLoading} onEdit={(page) => setCurrentPage(page)} />;
      case 'result':
        // FIX: Changed incorrect 'onNewDiagnosis' prop to 'onFinish' to match the component's definition.
        return <DiagnosisResultDisplay result={diagnosisResult} isLoading={isLoading} t={t} onFinish={handleNewDiagnosis} error={error} />;
      default:
        // FIX: Passed required props to LandingPage in the default case as well.
        return <LandingPage t={t} onStart={handleStartNewDiagnosis} patients={patients} onSelectPatient={handleSelectPatient} onDeletePatient={handleDeletePatient} />;
    }
  }

  const LanguageSelector = () => (
    <div className="absolute top-4 right-4 z-10">
      <select 
        value={language} 
        onChange={(e) => setLanguage(e.target.value as 'en' | 'te' | 'hi')}
        className="bg-white border border-slate-300 rounded-md shadow-sm px-3 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        aria-label="Select language"
      >
        <option value="en">English</option>
        <option value="te">తెలుగు</option>
        <option value="hi">हिन्दी</option>
      </select>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-100 font-sans text-slate-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 relative">
        <LanguageSelector />
        <header className="text-center mb-8">
          <div className="flex items-center justify-center gap-4">
             <StethoscopeIcon className="h-10 w-10 text-blue-600" />
            <h1 className="text-4xl font-bold text-slate-900">{t.appName}</h1>
          </div>
          <p className="mt-2 text-slate-600 max-w-2xl mx-auto">
            {t.appSubtitle} <span className="font-semibold text-red-600">{t.clinicalUseWarning}</span>
          </p>
        </header>

        <main className="mb-12">
            {renderCurrentPage()}
        </main>
      </div>
    </div>
  );
};

export default App;