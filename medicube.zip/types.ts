export interface ImageFile {
  file: File;
  base64: string;
}

export interface MedicalImages {
  xray: ImageFile | null;
  mri: ImageFile | null;
  ct: ImageFile | null;
  other: ImageFile | null;
}

export interface PatientHistory {
  name: string;
  age: string;
  gender: 'male' | 'female' | 'other';
  symptoms: string;
  medicalHistory: string;
  bloodPressure: string;
  bloodSugar: string;
}

export interface DiagnosisResult {
  predictedDiseases: {
    disease: string;
    confidence: number;
    explanation: string;
  }[];
  summary: string;
  overallRisk: 'Low' | 'Medium' | 'High';
}

export interface Patient {
  id: string;
  timestamp: number;
  history: PatientHistory;
  images: MedicalImages;
  result: DiagnosisResult;
}
