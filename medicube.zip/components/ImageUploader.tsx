import React, { useState } from 'react';
import { UploadIcon } from './icons/UploadIcon';
import type { ImageFile } from '../types';
import { XIcon } from './icons/XIcon';

interface ImageUploaderProps {
  onImageChange: (file: File | null) => void;
  medicalImage: ImageFile | null;
  t: { [key: string]: string };
  uploaderId: string;
}

export const ImageUploader: React.FC<ImageUploaderProps> = ({ onImageChange, medicalImage, t, uploaderId }) => {
  const [isDragging, setIsDragging] = useState(false);
  const inputId = `image-upload-${uploaderId}`;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onImageChange(e.target.files[0]);
    }
  };

  const handleDragEnter = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };
  
  const handleDragLeave = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };
  
  const handleDragOver = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent<HTMLLabelElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      onImageChange(e.dataTransfer.files[0]);
    }
  };

  return (
    <div>
      <label
        htmlFor={inputId}
        onDragEnter={handleDragEnter}
        onDragLeave={handleDragLeave}
        onDragOver={handleDragOver}
        onDrop={handleDrop}
        className={`flex justify-center w-full h-32 px-4 transition bg-white border-2 border-slate-300 border-dashed rounded-md appearance-none cursor-pointer hover:border-slate-400 focus:outline-none ${isDragging ? 'border-blue-500' : ''}`}
      >
        <span className="flex items-center space-x-2">
          <UploadIcon className="w-6 h-6 text-slate-600" />
          <span className="font-medium text-slate-600">
            {t.dropImage} <span className="text-blue-600 underline">{t.browse}</span>
          </span>
        </span>
        <input id={inputId} type="file" name="file_upload" className="hidden" accept="image/png, image/jpeg, image/webp" onChange={handleFileChange} value="" />
      </label>
      {medicalImage && (
        <div className="mt-4">
          <p className="text-sm font-medium text-slate-700">{t.imagePreview}</p>
          <div className="mt-2 border border-slate-200 rounded-lg p-2 inline-block relative">
             <img src={medicalImage.base64} alt="Medical scan preview" className="max-h-48 rounded-md" />
             <button
                type="button"
                onClick={() => onImageChange(null)}
                className="absolute top-0 right-0 -mt-2 -mr-2 bg-white rounded-full p-1 shadow-md hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 transition-colors"
                aria-label="Remove image"
             >
                <XIcon className="h-4 w-4 text-red-600" />
             </button>
          </div>
          <p className="text-xs text-slate-500 mt-1">{medicalImage.file.name}</p>
        </div>
      )}
    </div>
  );
};