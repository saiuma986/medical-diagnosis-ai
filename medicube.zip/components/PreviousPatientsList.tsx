import React from 'react';
import type { Patient } from '../types';
import { UserGroupIcon } from './icons/UserGroupIcon';
import { TrashIcon } from './icons/TrashIcon';

interface PreviousPatientsListProps {
  patients: Patient[];
  onSelectPatient: (patient: Patient) => void;
  onDeletePatient: (patientId: string) => void;
  t: { [key: string]: string };
}

export const PreviousPatientsList: React.FC<PreviousPatientsListProps> = ({ patients, onSelectPatient, onDeletePatient, t }) => {
  if (patients.length === 0) {
    return (
      <div className="mt-12 text-center text-slate-500">
        <p>{t.noRecentPatients}</p>
      </div>
    );
  }
  
  const handleDelete = (e: React.MouseEvent<HTMLButtonElement>, patientId: string) => {
    e.stopPropagation();
    onDeletePatient(patientId);
  };

  return (
    <div className="mt-12">
      <div className="flex items-center gap-3 mb-4">
        <UserGroupIcon className="h-6 w-6 text-slate-600" />
        <h3 className="text-2xl font-bold text-slate-800">{t.recentPatients}</h3>
      </div>
      <div className="bg-white rounded-2xl shadow-lg p-4 space-y-3">
        {patients.map((patient) => (
          <div
            key={patient.id}
            className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 rounded-lg bg-slate-50 border border-slate-200 hover:bg-slate-100 hover:border-blue-300 transition-colors"
          >
            <div className="flex-1 mb-3 sm:mb-0">
              <p className="font-bold text-lg text-slate-800">{patient.history.name}</p>
              <p className="text-sm text-slate-500">
                {`${t.diagnosedOn}: ${new Date(patient.timestamp).toLocaleDateString()}`} &bull; {patient.history.age} years old
              </p>
            </div>
            <div className="flex items-center gap-2 self-end sm:self-center">
              <button
                type="button"
                onClick={() => onSelectPatient(patient)}
                className="text-sm bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-md transition-colors"
                aria-label={`${t.viewReport} for ${patient.history.name}`}
              >
                {t.viewReport}
              </button>
              <button
                type="button"
                onClick={(e) => handleDelete(e, patient.id)}
                className="p-2 rounded-md hover:bg-red-100 group transition-colors"
                aria-label={`${t.delete} patient ${patient.history.name}`}
              >
                <TrashIcon className="h-5 w-5 text-slate-500 group-hover:text-red-600 transition-colors pointer-events-none" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
