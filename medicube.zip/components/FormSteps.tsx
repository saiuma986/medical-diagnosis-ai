import React, { useState } from 'react';
import type { PatientHistory, ImageFile, MedicalImages } from '../types';
import { ImageUploader } from './ImageUploader';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

type Translation = { [key: string]: string };

interface StepProps {
    patientHistory: PatientHistory;
    t: Translation;
}

interface PatientDetailsProps extends StepProps {
    onFormChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
}

interface MedicalInfoProps extends StepProps {
    onFormChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
}

interface ImageUploadProps {
    medicalImages: MedicalImages;
    onImageChange: (file: File | null, type: keyof MedicalImages) => void;
    t: Translation;
}

interface ReviewProps extends StepProps {
    medicalImages: MedicalImages;
    onEdit: (page: 'details' | 'medical' | 'image') => void;
}

export const Step1_PatientDetails: React.FC<PatientDetailsProps> = ({ patientHistory, onFormChange, t }) => (
    <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-4">{t.step1}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-slate-700">{t.name}</label>
                <input type="text" name="name" id="name" value={patientHistory.name} onChange={onFormChange} className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder={t.namePlaceholder} required />
            </div>
            <div>
                <label htmlFor="age" className="block text-sm font-medium text-slate-700">{t.age}</label>
                <input type="number" name="age" id="age" value={patientHistory.age} onChange={onFormChange} className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder={t.agePlaceholder} required />
            </div>
            <div className='md:col-span-2'>
                <label htmlFor="gender" className="block text-sm font-medium text-slate-700">{t.gender}</label>
                <select name="gender" id="gender" value={patientHistory.gender} onChange={onFormChange} className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm">
                    <option value="male">{t.male}</option>
                    <option value="female">{t.female}</option>
                    <option value="other">{t.other}</option>
                </select>
            </div>
        </div>
    </div>
);

export const Step2_MedicalInfo: React.FC<MedicalInfoProps> = ({ patientHistory, onFormChange, t }) => (
    <div>
        <h2 className="text-2xl font-bold text-slate-800 mb-4">{t.step2}</h2>
        <div className="space-y-4">
            <div>
                <label htmlFor="symptoms" className="block text-sm font-medium text-slate-700">{t.symptoms}</label>
                <textarea name="symptoms" id="symptoms" rows={4} value={patientHistory.symptoms} onChange={onFormChange} className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder={t.symptomsPlaceholder} required></textarea>
            </div>
            <div>
                <label htmlFor="medicalHistory" className="block text-sm font-medium text-slate-700">{t.medicalHistory}</label>
                <textarea name="medicalHistory" id="medicalHistory" rows={4} value={patientHistory.medicalHistory} onChange={onFormChange} className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder={t.medicalHistoryPlaceholder} required></textarea>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label htmlFor="bloodPressure" className="block text-sm font-medium text-slate-700">{t.bloodPressure}</label>
                    <input type="text" name="bloodPressure" id="bloodPressure" value={patientHistory.bloodPressure} onChange={onFormChange} className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder={t.bloodPressurePlaceholder} />
                </div>
                <div>
                    <label htmlFor="bloodSugar" className="block text-sm font-medium text-slate-700">{t.bloodSugar}</label>
                    <input type="text" name="bloodSugar" id="bloodSugar" value={patientHistory.bloodSugar} onChange={onFormChange} className="mt-1 block w-full px-3 py-2 bg-white border border-slate-300 rounded-md shadow-sm placeholder-slate-400 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm" placeholder={t.bloodSugarPlaceholder} />
                </div>
            </div>
        </div>
    </div>
);


export const Step3_ImageUpload: React.FC<ImageUploadProps> = ({ medicalImages, onImageChange, t }) => {
    const [selectedType, setSelectedType] = useState<keyof MedicalImages>('xray');

    const reportTypes: (keyof MedicalImages)[] = ['xray', 'mri', 'ct', 'other'];
    const reportTypeTranslations: { [key in keyof MedicalImages]: string } = {
        xray: t.xray,
        mri: t.mri,
        ct: t.ct,
        other: t.otherReport,
    };

    return (
        <div>
            <h2 className="text-2xl font-bold text-slate-800 mb-4">{t.step3}</h2>
            <p className="text-sm text-slate-600 mb-6">{t.uploadMedicalReports}</p>

            <div className="rounded-lg border border-slate-200 bg-slate-50">
                <nav className="flex flex-wrap border-b border-slate-200" aria-label="Report types">
                    {reportTypes.map(type => (
                        <button
                            key={type}
                            type="button"
                            role="tab"
                            aria-selected={selectedType === type}
                            onClick={() => setSelectedType(type)}
                            className={`flex-grow sm:flex-grow-0 flex items-center justify-center gap-2 px-4 py-3 text-sm font-medium border-b-2 -mb-px transition-colors
                                ${selectedType === type
                                    ? 'border-blue-600 text-blue-600 bg-white'
                                    : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
                                }`}
                        >
                            {reportTypeTranslations[type]}
                            {medicalImages[type] && <CheckCircleIcon className="h-5 w-5 text-green-500 flex-shrink-0" />}
                        </button>
                    ))}
                </nav>

                <div className="p-6 bg-white" role="tabpanel">
                    <ImageUploader
                        uploaderId={selectedType}
                        onImageChange={(file) => onImageChange(file, selectedType)}
                        medicalImage={medicalImages[selectedType]}
                        t={t}
                        key={selectedType}
                    />
                </div>
            </div>
        </div>
    );
};


export const Step4_Review: React.FC<ReviewProps> = ({ patientHistory, medicalImages, t, onEdit }) => {
    const renderField = (label: string, value: string | undefined, pageToEdit: 'details' | 'medical') => (
        <div className="flex justify-between items-start py-2 border-b border-slate-200">
            <dt className="text-sm font-medium text-slate-500">{label}</dt>
            <dd className="text-sm text-slate-900 text-right ml-4 flex items-center gap-2">
                <span className="break-all">{value || 'N/A'}</span>
                <button onClick={() => onEdit(pageToEdit)} className="text-blue-600 hover:underline text-xs flex-shrink-0">Edit</button>
            </dd>
        </div>
    );
    
    const uploadedImages = Object.entries(medicalImages).filter(([, imageFile]) => imageFile !== null) as [string, ImageFile][];
    const reportTypeTranslations: { [key: string]: string } = {
        xray: t.xray,
        mri: t.mri,
        ct: t.ct,
        other: t.otherReport,
    };

    return (
        <div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">{t.reviewTitle}</h2>
            <p className="text-sm text-slate-600 mb-4">{t.reviewSubtitle}</p>
            <div className="space-y-2 rounded-lg border border-slate-200 p-4">
                <h3 className="font-semibold text-lg mb-2">{t.step1}</h3>
                <dl>
                    {renderField(t.name, patientHistory.name, 'details')}
                    {renderField(t.age, patientHistory.age, 'details')}
                    {renderField(t.gender, patientHistory.gender, 'details')}
                </dl>
                <h3 className="font-semibold text-lg mt-4 mb-2">{t.step2}</h3>
                <dl>
                    {renderField(t.symptoms, patientHistory.symptoms, 'medical')}
                    {renderField(t.medicalHistory, patientHistory.medicalHistory, 'medical')}
                    {renderField(t.bloodPressure, patientHistory.bloodPressure, 'medical')}
                    {renderField(t.bloodSugar, patientHistory.bloodSugar, 'medical')}
                </dl>
                 <div className="flex justify-between items-center mt-4 mb-2">
                    <h3 className="font-semibold text-lg">{t.step3}</h3>
                    <button onClick={() => onEdit('image')} className="text-blue-600 hover:underline text-xs">Edit</button>
                 </div>
                 {uploadedImages.length > 0 ? (
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                        {uploadedImages.map(([type, imageFile]) => (
                            <div key={type}>
                                <p className="text-sm font-medium text-slate-600 capitalize mb-1">{reportTypeTranslations[type] || type}</p>
                                <img src={imageFile.base64} alt={`${type} preview`} className="h-24 w-full object-contain rounded-md border p-1 bg-slate-50" />
                            </div>
                        ))}
                    </div>
                 ) : (
                    <p className="text-sm text-slate-500 py-2">No medical reports uploaded.</p>
                 )}
            </div>
        </div>
    );
};