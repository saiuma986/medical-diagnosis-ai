import React from 'react';
import type { DiagnosisResult } from '../types';
import { AlertIcon } from './icons/AlertIcon';

interface DiagnosisResultDisplayProps {
  result: DiagnosisResult | null;
  isLoading: boolean;
  t: { [key: string]: string };
  onFinish: () => void;
  error?: string | null;
}

const LoadingSkeleton: React.FC = () => (
    <div className="animate-pulse">
        <div className="h-6 bg-slate-200 rounded-md w-3/4 mb-4"></div>
        <div className="h-8 bg-slate-200 rounded-md w-1/3 mb-6"></div>
        <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
                <div key={i} className="p-4 border border-slate-200 rounded-lg">
                    <div className="h-4 bg-slate-200 rounded w-1/2 mb-2"></div>
                    <div className="h-8 bg-slate-200 rounded w-full"></div>
                    <div className="h-3 bg-slate-200 rounded w-5/6 mt-2"></div>
                </div>
            ))}
        </div>
        <div className="h-5 bg-slate-200 rounded-md w-1/2 mt-8 mb-4"></div>
         <div className="space-y-2">
            <div className="h-3 bg-slate-200 rounded w-full"></div>
            <div className="h-3 bg-slate-200 rounded w-full"></div>
            <div className="h-3 bg-slate-200 rounded w-4/5"></div>
        </div>
    </div>
);


const ConfidenceBar: React.FC<{ value: number }> = ({ value }) => {
    const getColor = (v: number) => {
        if (v > 75) return 'bg-red-500';
        if (v > 50) return 'bg-yellow-500';
        return 'bg-green-500';
    };

    return (
        <div className="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
            <div
                className={`h-2.5 rounded-full transition-all duration-500 ${getColor(value)}`}
                style={{ width: `${value}%` }}
            ></div>
        </div>
    );
};

const RiskBadge: React.FC<{ risk: 'Low' | 'Medium' | 'High', t: { [key: string]: string } }> = ({ risk, t }) => {
    const riskStyles = {
        Low: 'bg-green-100 text-green-800 border-green-300',
        Medium: 'bg-yellow-100 text-yellow-800 border-yellow-300',
        High: 'bg-red-100 text-red-800 border-red-300',
    };
    const riskKey = risk?.toLowerCase() as keyof typeof t;
    return (
        <span className={`px-3 py-1 text-sm font-semibold rounded-full border ${riskStyles[risk] || 'bg-slate-100 text-slate-800'}`}>
            {t[riskKey] || risk}
        </span>
    );
};


export const DiagnosisResultDisplay: React.FC<DiagnosisResultDisplayProps> = ({ result, isLoading, t, onFinish, error }) => {
    
    const renderContent = () => {
        if (isLoading) {
            return <LoadingSkeleton />;
        }

        if (error) {
             return (
                <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="bg-red-100 border border-red-200 text-red-700 p-6 rounded-lg max-w-md">
                        <div className="flex items-center justify-center mb-4">
                           <AlertIcon className="h-10 w-10 text-red-500" />
                        </div>
                        <h2 className="text-2xl font-bold mb-2">{t.error}</h2>
                        <p className="mb-6">{t.failedToGetDiagnosis}</p>
                        <button onClick={onFinish} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors">{t.newDiagnosis}</button>
                    </div>
                </div>
            );
        }
        
        if (!result) {
            return (
                <div className="flex flex-col items-center justify-center h-full text-center text-slate-500 p-8">
                    <h2 className="text-2xl font-bold text-slate-800 mb-2">{t.awaitingAnalysis}</h2>
                    <p>{t.resultsAppearHere}</p>
                </div>
            );
        }

        return (
            <div className="flex flex-col h-full">
                <div className="flex justify-between items-start mb-4">
                    <h2 className="text-3xl font-bold text-slate-800">{t.diagnosisReport}</h2>
                    <button onClick={onFinish} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-colors text-sm">{t.finish}</button>
                </div>

                <div className="mb-6 bg-slate-50 border border-slate-200 p-4 rounded-lg">
                    <h3 className="text-md font-semibold text-slate-600 mb-2">{t.overallRisk}</h3>
                    <RiskBadge risk={result.overallRisk} t={t} />
                </div>

                <div>
                    <h3 className="text-xl font-semibold text-slate-700 mb-3">{t.top3Conditions}</h3>
                    <div className="space-y-4">
                        {result.predictedDiseases.map((item) => (
                            <div key={item.disease} className="p-4 border border-slate-200 rounded-lg">
                               <div className="flex justify-between items-center mb-2">
                                    <h4 className="font-bold text-lg text-blue-700">{item.disease}</h4>
                                    <span className="font-semibold text-slate-800 text-sm">{item.confidence.toFixed(1)}%</span>
                               </div>
                               <ConfidenceBar value={item.confidence} />
                               <p className="text-sm text-slate-600 mt-2">{item.explanation}</p>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="mt-8 bg-slate-50 border border-slate-200 rounded-lg p-4">
                    <h3 className="text-xl font-semibold text-slate-700 mb-2">{t.summaryRecommendations}</h3>
                     <div className="text-sm text-slate-700 space-y-3">
                        <p className="leading-relaxed">{result.summary}</p>
                    </div>
                </div>
            </div>
        );
    };

    return (
      <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg min-h-[600px]">
          {renderContent()}
      </div>
    );
};
