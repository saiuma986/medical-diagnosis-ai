import React from 'react';
import type { PatientHistory, MedicalImages } from '../../types';
import { Step4_Review } from '../FormSteps';

interface ReviewPageProps {
  t: { [key: string]: string };
  patientHistory: PatientHistory;
  medicalImages: MedicalImages;
  onBack: () => void;
  onAnalyze: () => void;
  isLoading: boolean;
  onEdit: (page: 'details' | 'medical' | 'image') => void;
}

export const ReviewPage: React.FC<ReviewPageProps> = ({ t, patientHistory, medicalImages, onBack, onAnalyze, isLoading, onEdit }) => {
  const isAnalyzeButtonDisabled = !patientHistory.name || !patientHistory.age || !patientHistory.symptoms || isLoading;

  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg">
      <Step4_Review patientHistory={patientHistory} medicalImages={medicalImages} t={t} onEdit={onEdit} />
      <div className="mt-8">
        <div className="flex justify-between items-center">
          <button onClick={onBack} className="bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-3 px-6 rounded-lg transition-colors">{t.back}</button>
          <button onClick={onAnalyze} disabled={isAnalyzeButtonDisabled} className={`w-full max-w-xs ml-auto text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 flex items-center justify-center gap-2 ${isAnalyzeButtonDisabled ? 'bg-slate-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 transform hover:-translate-y-1 shadow-md hover:shadow-lg'}`}>
            {isLoading ? t.analyzing : t.runDiagnosis}
          </button>
        </div>
      </div>
    </div>
  );
};