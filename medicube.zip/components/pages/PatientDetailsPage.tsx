import React from 'react';
import type { PatientHistory } from '../../types';
import { Step1_PatientDetails } from '../FormSteps';
import { AlertIcon } from '../icons/AlertIcon';

interface PatientDetailsPageProps {
  t: { [key: string]: string };
  patientHistory: PatientHistory;
  onFormChange: (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => void;
  onNext: () => void;
  error: string | null;
}

export const PatientDetailsPage: React.FC<PatientDetailsPageProps> = ({ t, patientHistory, onFormChange, onNext, error }) => {
  return (
    <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg">
      <Step1_PatientDetails patientHistory={patientHistory} onFormChange={onFormChange} t={t} />
      <div className="mt-8">
        {error && (
          <div className="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 rounded-md flex items-start gap-3 mb-4" role="alert">
            <AlertIcon className="h-6 w-6 flex-shrink-0 mt-0.5" />
            <p>{error}</p>
          </div>
        )}
        <div className="flex justify-end items-center">
          <button onClick={onNext} className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-colors">{t.next}</button>
        </div>
      </div>
    </div>
  );
};
