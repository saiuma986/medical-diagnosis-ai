export * from './LandingPage';
export * from './PatientDetailsPage';
export * from './MedicalInfoPage';
export * from './ImageUploadPage';
export * from './ReviewPage';
