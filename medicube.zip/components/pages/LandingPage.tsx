import React from 'react';
import { PreviousPatientsList } from '../PreviousPatientsList';
import type { Patient } from '../../types';

interface LandingPageProps {
  t: { [key: string]: string };
  onStart: () => void;
  patients: Patient[];
  onSelectPatient: (patient: Patient) => void;
  onDeletePatient: (patientId: string) => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({ t, onStart, patients, onSelectPatient, onDeletePatient }) => {
  return (
    <>
      <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-lg flex flex-col items-center justify-center text-center">
        <h2 className="text-3xl font-bold text-slate-800 mb-4">{t.welcomeMessage}</h2>
        <p className="text-slate-600 mb-8 max-w-lg">{t.appSubtitle}</p>
        <button 
          onClick={onStart} 
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-8 rounded-lg transition-all duration-300 transform hover:-translate-y-1 shadow-md hover:shadow-lg text-lg"
        >
          {t.startDiagnosis}
        </button>
      </div>
      <PreviousPatientsList 
        patients={patients}
        onSelectPatient={onSelectPatient}
        onDeletePatient={onDeletePatient}
        t={t}
      />
    </>
  );
};
